Lanjutkan Project Laravel yang kita kerjakan pada Modul 06 Praktikum (aplikasi sederhana data master employee) 
dengan menerapkan Laravel Authentication yang sudah dipelajari pada project laravel tersebut

#Laravel #WidiyantiIntanPS 
